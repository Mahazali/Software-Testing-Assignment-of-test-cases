import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class PrimenoTestCases {
    Primeno  primeNumber=new Primeno();

    @BeforeEach
    public void print()
    {
        System.out.println("To check anuber is prime or not");
    }
    @Test
    public void isPrime()
    {
        Boolean exp=true;

        Boolean actual=primeNumber.chkprimenum(0);

        Assertions.assertEquals(actual,exp,"Not found");

    }
    @Test
    public void p1  ()
    {
        Boolean exp=false;

        Boolean actual=primeNumber.chkprimenum(2);
        Assertions.assertEquals(actual,exp,"Not found");


    }
    @Test
    public void p2()
    {
        Boolean exp=true;
        Boolean actual=primeNumber.chkprimenum(5);
        Assertions.assertEquals(actual,exp,"Not found");

    }
    @Test
    public void p3()
    {
        Boolean exp=false;
        Boolean actual=primeNumber.chkprimenum(10);
        Assertions.assertEquals(actual,exp,"Not found");

    }
    @Test
    public void p4()
    {
        Boolean exp=false;
        Boolean actual=primeNumber.chkprimenum(-1);
        Assertions.assertEquals(actual,exp,"Not found");

    }

}
