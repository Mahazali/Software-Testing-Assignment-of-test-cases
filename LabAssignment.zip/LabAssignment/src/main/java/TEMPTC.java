import org.junit.jupiter.api.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TEMPTC{
    Temperature temp=new Temperature();
    @BeforeAll
    public void start(){

        System.out.println("Testcases for TempratureConversion");
    }
    @BeforeEach
    public void beforeEach(){
        System.out.println("Before each Test Case");

    }
    @AfterEach
    public void afterEach(){
        System.out.println("Test case executed");
    }

    @Test
    public void tempratureTestCase1(){
        double celcius=35.5;
        double[] expected={308.65,95.9};
        double[] actual=temp.calculate(celcius);
        System.out.println(expected[0]+" "+actual[0]);
        Assertions.assertEquals(expected,actual);
    }


}
