import org.junit.jupiter.api.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AvgArrayTC {
    Addintegersarray avg=new Addintegersarray();

    @BeforeAll
    public void initialize(){

        System.out.println("Testcases for AverageOfArray");
    }
    @BeforeEach
    public void beforeEach(){
        System.out.println("Before each Test Case");

    }
    @AfterEach
    public void afterEach(){
        System.out.println("Testcase Executed");
    }
    @Test
    public void TC1(){
        int[] a={1,2,3,4,5};
        int actual=0;
        int expected=3;
        actual=avg.Average();
        Assertions.assertEquals(expected,actual);
    }
    @Test
    public void TC2(){
        int[] a={20};
        int actual=0;
        int expected=20;
        actual=avg.Average();
        Assertions.assertEquals(expected,actual);
    }
    public void TC3(){
        int[] a={60,20,40};
        int actual=0;
        int expected=40;
        actual=avg.Average();
        Assertions.assertEquals(expected,actual);
    }

}
