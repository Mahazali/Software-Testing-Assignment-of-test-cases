import org.junit.jupiter.api.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class evenoddtestcases {
    evenoddnum eo=new evenoddnum();
    @BeforeAll
    public void initialize(){

        System.out.println("Testcases for AverageOfArray");
    }
    @BeforeEach
    public void beforeEach(){
        System.out.println("Before each Test Case");

    }
    @AfterEach
    public void afterEach(){
        System.out.println("Testcase Executed");
    }
    @Test
    public void TC1() {
        int num = 4;
        boolean actual = true;
        boolean expected = true;
        actual = eo.chkevenodd(num);
        Assertions.assertEquals(expected, actual);
    }
    @Test
    public void TC2() {
        int num = -4;
        boolean actual = true;
        boolean expected = true;
        actual = eo.chkevenodd(num);
        Assertions.assertEquals(expected, actual);
    } @Test
    public void TC3() {
        int num = 9;
        boolean actual = true;
        boolean expected = false;
        actual = eo.chkevenodd(num);
        Assertions.assertEquals(expected, actual);
    } @Test
    public void TC4() {
        int num = -1;
        boolean actual = true;
        boolean expected = false;
        actual = eo.chkevenodd(num);
        Assertions.assertEquals(expected, actual);
    }
    @Test
    public void TC5() {
        int num = 0;
        boolean actual = true;
        boolean expected = true;
        actual = eo.chkevenodd(num);
        Assertions.assertEquals(expected, actual);
    }
}
