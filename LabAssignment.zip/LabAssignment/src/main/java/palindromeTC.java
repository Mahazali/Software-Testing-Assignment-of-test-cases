import org.junit.jupiter.api.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class palindromeTC {
    palindrome p=new palindrome();
    @BeforeAll
    public void initialize(){
        // PrimeNumber n=new PrimeNumber();
        System.out.println("Testcases for Palendrome");
    }
    @BeforeEach
    public void beforeEach(){
        System.out.println("Executing Test Case");

    }
    @AfterEach
    public void afterEach(){
        System.out.println("Executed Successfully");
    }
    @Test
    public void TC1(){
        String str1="car";
        String str2="rar";
        boolean actual=false;
        boolean expected=false;
        actual=p.chkPalendromic(str1,str2);
        Assertions.assertEquals(expected,actual);
    }
    @Test
    public void TC2(){
        String str1="car";
        String str2="rac";
        boolean actual=true;
        boolean expected=true;
        actual=p.chkPalendromic(str1,str2);
        Assertions.assertEquals(expected,actual);
    }
}
