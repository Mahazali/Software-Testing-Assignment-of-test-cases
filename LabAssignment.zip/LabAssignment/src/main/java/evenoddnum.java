public class evenoddnum implements evenoddnumber{
    private int number;
    public evenoddnum(int number) {
        this.number = number;
    }
    public evenoddnum() {
    }
    public Boolean chkevenodd(Integer num){
        this.number=num;
        boolean ifEven=true;
        if(number%2==0){
            ifEven=true;
        }
        else{ifEven=false;}
        return ifEven;
    }

}
