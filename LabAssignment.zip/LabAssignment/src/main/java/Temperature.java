import java.text.DecimalFormat;

public class Temperature implements TemperatureInt{
    public double[] calculate(double celcius) {
        double k=celciusToKelvin(celcius);
        double f=celciusToFaren(celcius);
        DecimalFormat d = new DecimalFormat("0.00");
        double[] array={k,f};
        return array;
    }
    public double celciusToKelvin(double celcius) {
        return celcius + 271.15;
    }
    public double celciusToFaren(double celcius) {
        double f=1.80*(celcius)+32;
        return f;
    }
}
