public interface palindromeInt {
    public boolean chkPalendromic(String str1,String str2);
}
