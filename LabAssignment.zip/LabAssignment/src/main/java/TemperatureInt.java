public interface TemperatureInt {
    public double[] calculate(double celcius);
    public double celciusToKelvin(double celcius);
    public double celciusToFaren(double celcius);
}
