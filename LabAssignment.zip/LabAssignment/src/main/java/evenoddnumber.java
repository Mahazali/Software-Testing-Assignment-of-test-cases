public interface evenoddnumber {
    public Boolean chkevenodd(Integer num);
}
