
import org.junit.jupiter.api.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PrimeNumberTC {
    Primeno n=new Primeno();
    @BeforeAll
    public void initialize(){

        System.out.println("Testcases for PrimeNumbers");
    }
    @BeforeEach
    public void beforeEach(){
        System.out.println("Before Test Case");

    }
    @AfterEach
    public void afterEach(){
        System.out.println("Test case executed");
    }
    @Test
    public void TC1(){
        int num=3;
        boolean actual=true;
        boolean expected=true;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);
    }
    @Test
    public void TC2(){
        int num=0;
        boolean actual=true;
        boolean expected=false;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);
    }

    @Test
    public void TC3(){
        int num=-5;
        boolean actual=true;
        boolean expected=false;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);
    }
    @Test
    public void TC4(){
        int num=12;
        boolean actual=true;
        boolean expected=false;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);

    }
    @Test
    public void TC5(){
        int num=-5677;
        boolean actual=true;
        boolean expected=false;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);

    }


    @Test
    public void primeTestCase6(){
        int num=100003;
        boolean actual=true;
        boolean expected=true;
        actual=n.chkprimenum(num);
        Assertions.assertEquals(expected,actual);

    }

}
