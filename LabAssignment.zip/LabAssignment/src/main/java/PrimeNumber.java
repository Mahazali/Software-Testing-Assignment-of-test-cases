public interface PrimeNumber {
        public Boolean chkprimenum(Integer num);
    }