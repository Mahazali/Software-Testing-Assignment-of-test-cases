public class Addintegersarray {
    int[] a;
    public Addintegersarray() {
        this.a = a;
    }
    public int Average(){
        int sum = 0;
        for (int value : this.a) {
            sum += value;
        }
        return sum/a.length;
    }
}
