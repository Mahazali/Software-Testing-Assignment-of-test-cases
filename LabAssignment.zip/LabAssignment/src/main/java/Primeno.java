public class Primeno implements PrimeNumber{
    private int number;
    public Boolean chkprimenum(Integer num) {
        Boolean isPrime=true;
        if(num<=1){
            return false;
        }
        else{
            for(int i=2;i<num;i++){
                if(num%i==0){
                    isPrime=false;
                    break;
                }
            }
        }

        return isPrime;
    }
}
